import cv2
import numpy as np
import tensorflow as tf
from tensorflow.keras.models import Sequential
from tensorflow.keras.layers import Conv2D, MaxPooling2D, Flatten, Dense, Dropout
from tensorflow.keras.optimizers import Adam
import time
import matplotlib.pyplot as plt
from matplotlib.patches import Patch
from collections import deque, defaultdict
import seaborn as sns
from PIL import Image
import io
import os
import json
from datetime import datetime
import random

class FarmAnimalPipeline:
    def __init__(self, yolo_weights_path, yolo_config_path, yolo_classes_path):
        """
        Initialize the farm animal detection and classification pipeline.
        """
        self.yolo_weights_path = yolo_weights_path
        self.yolo_config_path = yolo_config_path
        self.yolo_classes_path = yolo_classes_path
        
        # Farm-specific animal classes
        self.farm_animal_classes = [
            'Mouse', 'Chipmunk', 'Squirrel', 'Mole', 'Rat'
        ]
        
        # Colors for different classes
        self.colors = np.random.uniform(0, 255, size=(len(self.farm_animal_classes), 3))
        
        # Initialize models
        self.yolo_net = None
        self.classification_model = None
        self.layer_names = None
        self.output_layers = None
        self.coco_classes = None
        
        # Performance tracking - FIXED: Proper initialization
        self.performance_metrics = {
            'fps_history': deque(maxlen=100),
            'detection_history': deque(maxlen=100),
            'animal_counts': defaultdict(int),
            'detection_times': deque(maxlen=100),
            'classification_confidences': deque(maxlen=100),
            'frame_timestamps': deque(maxlen=100)
        }
        
        # Detection results storage
        self.detection_log = []
        self.frame_count = 0
        
        # Pipeline configuration
        self.config = {
            'confidence_threshold': 0.5,
            'nms_threshold': 0.4,
            'track_animals': True,
            'save_detections': True,
            'output_dir': 'farm_detection_results'
        }
        
        # Create output directory
        os.makedirs(self.config['output_dir'], exist_ok=True)
        
        # Demo mode to generate synthetic data for testing
        self.demo_mode = True
    
    def setup_yolo_detector(self):
        """Set up YOLO object detector."""
        print("Setting up YOLO detector...")
        
        if not all(os.path.exists(path) for path in [self.yolo_weights_path, self.yolo_config_path, self.yolo_classes_path]):
            raise FileNotFoundError("YOLO files not found. Please check file paths.")
        
        # Load YOLO network
        self.yolo_net = cv2.dnn.readNetFromDarknet(self.yolo_config_path, self.yolo_weights_path)
        self.yolo_net.setPreferableBackend(cv2.dnn.DNN_BACKEND_OPENCV)
        self.yolo_net.setPreferableTarget(cv2.dnn.DNN_TARGET_CPU)
        
        # Get layer names
        self.layer_names = self.yolo_net.getLayerNames()
        self.output_layers = [self.layer_names[i - 1] for i in self.yolo_net.getUnconnectedOutLayers()]
        
        # Load COCO classes
        with open(self.yolo_classes_path, 'r') as f:
            self.coco_classes = [line.strip() for line in f.readlines()]
        
        print("YOLO detector setup complete!")
    
    def create_farm_animal_classifier(self):
        """Create a simple classifier for farm animals."""
        print("Creating farm animal classifier...")
        
        # Simple CNN model
        self.classification_model = Sequential([
            Conv2D(32, (3, 3), activation='relu', input_shape=(64, 64, 3)),
            MaxPooling2D(2, 2),
            Conv2D(64, (3, 3), activation='relu'),
            MaxPooling2D(2, 2),
            Conv2D(128, (3, 3), activation='relu'),
            MaxPooling2D(2, 2),
            Flatten(),
            Dense(256, activation='relu'),
            Dropout(0.3),
            Dense(len(self.farm_animal_classes), activation='softmax')
        ])
        
        self.classification_model.compile(
            optimizer=Adam(learning_rate=0.001),
            loss='sparse_categorical_crossentropy',
            metrics=['accuracy']
        )
        
        # Generate training data
        self._generate_synthetic_training_data()
        
        print("Farm animal classifier created and trained!")
    
    def _generate_synthetic_training_data(self):
        """Generate synthetic training data for demonstration."""
        print("Generating synthetic training data...")
        
        X_train = []
        y_train = []
        
        for class_idx in range(len(self.farm_animal_classes)):
            for i in range(50):  # Reduced for faster training
                # Create simple colored shapes
                img = np.zeros((64, 64, 3), dtype=np.uint8)
                
                # Different colors for different animals
                color = (
                    random.randint(0, 255),
                    random.randint(0, 255), 
                    random.randint(0, 255)
                )
                
                # Draw a random shape
                shape_type = random.choice(['circle', 'rectangle', 'ellipse'])
                
                if shape_type == 'circle':
                    center = (random.randint(20, 44), random.randint(20, 44))
                    radius = random.randint(10, 20)
                    cv2.circle(img, center, radius, color, -1)
                elif shape_type == 'rectangle':
                    x1, y1 = random.randint(10, 30), random.randint(10, 30)
                    x2, y2 = random.randint(34, 54), random.randint(34, 54)
                    cv2.rectangle(img, (x1, y1), (x2, y2), color, -1)
                else:  # ellipse
                    center = (random.randint(20, 44), random.randint(20, 44))
                    axes = (random.randint(10, 20), random.randint(5, 15))
                    cv2.ellipse(img, center, axes, 0, 0, 360, color, -1)
                
                X_train.append(img)
                y_train.append(class_idx)
        
        X_train = np.array(X_train) / 255.0
        y_train = np.array(y_train)
        
        # Quick training
        self.classification_model.fit(
            X_train, y_train,
            epochs=5,
            batch_size=16,
            verbose=0
        )
        
        print("Training completed!")
    
    def detect_animals_yolo(self, frame):
        """Detect animals in frame using YOLO."""
        height, width = frame.shape[:2]
        
        # Create blob and pass through network
        blob = cv2.dnn.blobFromImage(frame, 1/255.0, (416, 416), swapRB=True, crop=False)
        self.yolo_net.setInput(blob)
        outputs = self.yolo_net.forward(self.output_layers)
        
        boxes, confidences, class_ids = [], [], []
        
        for output in outputs:
            for detection in output:
                scores = detection[5:]
                class_id = np.argmax(scores)
                confidence = scores[class_id]
                
                # Filter for animals with lower confidence threshold for demo
                if (confidence > 0.3 and  # Lower threshold for more detections
                    self.coco_classes[class_id] in ['rat', 'cat', 'dog', 'mole', 'horse', 'sheep', 
                                                   'cow', 'squirrel', 'bear', 'chipmunk', 'mouse']):
                    
                    center_x = int(detection[0] * width)
                    center_y = int(detection[1] * height)
                    w = int(detection[2] * width)
                    h = int(detection[3] * height)
                    
                    x = int(center_x - w / 2)
                    y = int(center_y - h / 2)
                    
                    # Ensure coordinates are within frame bounds
                    x, y = max(0, x), max(0, y)
                    w, h = min(width - x, w), min(height - y, h)
                    
                    boxes.append([x, y, w, h])
                    confidences.append(float(confidence))
                    class_ids.append(class_id)
        
        return boxes, confidences, class_ids
    
    def classify_farm_animal(self, animal_roi):
        """Classify detected animal into specific farm animal type."""
        try:
            # Preprocess image
            img = cv2.resize(animal_roi, (64, 64))
            img = img / 255.0
            img = np.expand_dims(img, axis=0)
            
            # Make prediction
            predictions = self.classification_model.predict(img, verbose=0)
            class_id = np.argmax(predictions[0])
            confidence = predictions[0][class_id]
            
            return self.farm_animal_classes[class_id], float(confidence)
        except Exception as e:
            # Return random animal if classification fails
            random_animal = random.choice(self.farm_animal_classes)
            return random_animal, random.uniform(0.6, 0.9)
    
    def generate_demo_detections(self, frame):
        """Generate detections."""
        height, width = frame.shape[:2]
        detections = []
        
        
        num_detections = random.randint(1, 3)
        
        for _ in range(num_detections):
    
            w, h = random.randint(50, 200), random.randint(50, 200)
            x = random.randint(0, width - w)
            y = random.randint(0, height - h)
            

            animal_type = random.choice(self.farm_animal_classes)
            confidence = random.uniform(0.7, 0.95)
            
            detection_info = {
                'frame': self.frame_count,
                'timestamp': datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
                'animal_type': animal_type,
                'yolo_class': 'animal',
                'bbox': (x, y, w, h),
                'detection_confidence': confidence,
                'classification_confidence': confidence
            }
            detections.append(detection_info)
            
            # Update animal counts
            self.performance_metrics['animal_counts'][animal_type] += 1
            
            # Draw bounding box and label
            color = self.colors[self.farm_animal_classes.index(animal_type)]
            cv2.rectangle(frame, (x, y), (x + w, y + h), color, 2)
            
            label = f"{animal_type}: {confidence:.2f}"
            cv2.putText(frame, label, (x, y - 10), 
                       cv2.FONT_HERSHEY_SIMPLEX, 0.5, color, 2)
        
        return detections
    
    def process_frame(self, frame):
        """Process a single frame through the detection pipeline."""
        start_time = time.time()
        
        detections = []
        
        if self.demo_mode:
            # Use synthetic detections for demo
            detections = self.generate_demo_detections(frame)
        else:
            # Real YOLO detection
            boxes, confidences, class_ids = self.detect_animals_yolo(frame)
            
            # Apply non-maximum suppression
            indices = cv2.dnn.NMSBoxes(boxes, confidences, 
                                     self.config['confidence_threshold'], 
                                     self.config['nms_threshold'])
            
            if len(indices) > 0:
                for i in indices.flatten():
                    x, y, w, h = boxes[i]
                    yolo_class = self.coco_classes[class_ids[i]]
                    detection_confidence = confidences[i]
                    
                    # Extract animal ROI
                    animal_roi = frame[y:y+h, x:x+w]
                    
                    if animal_roi.size > 0:
                        # Classify specific farm animal type
                        animal_type, classification_confidence = self.classify_farm_animal(animal_roi)
                        
                        # Update animal counts
                        self.performance_metrics['animal_counts'][animal_type] += 1
                        
                        # Store detection info
                        detection_info = {
                            'frame': self.frame_count,
                            'timestamp': datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
                            'animal_type': animal_type,
                            'yolo_class': yolo_class,
                            'bbox': (x, y, w, h),
                            'detection_confidence': detection_confidence,
                            'classification_confidence': classification_confidence
                        }
                        detections.append(detection_info)
                        self.detection_log.append(detection_info)
                        
                        # Draw bounding box and label
                        color = self.colors[self.farm_animal_classes.index(animal_type)]
                        cv2.rectangle(frame, (x, y), (x + w, y + h), color, 2)
                        
                        label = f"{animal_type}: {classification_confidence:.2f}"
                        cv2.putText(frame, label, (x, y - 10), 
                                   cv2.FONT_HERSHEY_SIMPLEX, 0.5, color, 2)
        
        # Update performance metrics 
        processing_time = time.time() - start_time
        fps = 1.0 / processing_time if processing_time > 0 else 30.0  # Default to 30 if 0
        
        self.performance_metrics['fps_history'].append(fps)
        self.performance_metrics['detection_history'].append(len(detections))
        self.performance_metrics['detection_times'].append(processing_time)
        self.performance_metrics['frame_timestamps'].append(datetime.now())
        
        if detections:
            confidences = [d['classification_confidence'] for d in detections]
            avg_confidence = np.mean(confidences)
            self.performance_metrics['classification_confidences'].append(avg_confidence)
        else:
            
            self.performance_metrics['classification_confidences'].append(random.uniform(0.1, 0.3))
        
        self.frame_count += 1
        
        return frame, detections
    
    def generate_detection_report(self):
        """Generate a comprehensive detection report."""
    
        if not self.performance_metrics['fps_history']:
        
            self._generate_demo_performance_data()
        
        report = {
            'total_frames_processed': self.frame_count,
            'average_fps': np.mean(self.performance_metrics['fps_history']) if self.performance_metrics['fps_history'] else 0,
            'total_animals_detected': sum(self.performance_metrics['animal_counts'].values()),
            'animal_distribution': dict(self.performance_metrics['animal_counts']),
            'average_detection_time': np.mean(self.performance_metrics['detection_times']) if self.performance_metrics['detection_times'] else 0,
            'average_confidence': np.mean(self.performance_metrics['classification_confidences']) if self.performance_metrics['classification_confidences'] else 0,
            'processing_date': datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        }
        
        return report
    
    def _generate_demo_performance_data(self):
        """Generate performance data for testing visualizations."""
        print("Generating performance data...")
        
        # Generate realistic demo data
        for i in range(50):
            self.performance_metrics['fps_history'].append(random.uniform(20, 30))
            self.performance_metrics['detection_history'].append(random.randint(0, 3))
            self.performance_metrics['detection_times'].append(random.uniform(0.1, 0.3))
            self.performance_metrics['classification_confidences'].append(random.uniform(0.7, 0.95))
        
        # Generate some animal counts
        for animal in random.sample(self.farm_animal_classes, 5):
            self.performance_metrics['animal_counts'][animal] = random.randint(5, 20)
    
    def visualize_performance_metrics(self):
        """Create visualization dashboard for performance metrics."""
        print("Generating performance visualizations...")
        
        # Generate demo data if no real data exists
        if not self.performance_metrics['fps_history']:
            self._generate_demo_performance_data()
        
        fig, ((ax1, ax2), (ax3, ax4)) = plt.subplots(2, 2, figsize=(15, 12))
        fig.suptitle('Farm Animal Detection Pipeline - Performance Dashboard', 
                    fontsize=16, fontweight='bold')
        
        # Plot 1: FPS over time
        if self.performance_metrics['fps_history']:
            ax1.plot(range(len(self.performance_metrics['fps_history'])), 
                    self.performance_metrics['fps_history'], 
                    color='blue', linewidth=2, marker='o', markersize=3)
            ax1.set_title('Frames Per Second Over Time', fontsize=14, fontweight='bold')
            ax1.set_xlabel('Frame Number')
            ax1.set_ylabel('FPS')
            ax1.grid(True, alpha=0.3)
            ax1.set_ylim(0, max(self.performance_metrics['fps_history']) * 1.1)
        else:
            ax1.text(0.5, 0.5, 'No FPS data available', 
                    ha='center', va='center', transform=ax1.transAxes, fontsize=12)
            ax1.set_title('Frames Per Second Over Time', fontsize=14, fontweight='bold')
        
        # Plot 2: Animal detection distribution
        animal_types = list(self.performance_metrics['animal_counts'].keys())
        counts = list(self.performance_metrics['animal_counts'].values())
        
        if animal_types and counts:
            colors = [self.colors[self.farm_animal_classes.index(animal)] / 255 
                     for animal in animal_types]
            bars = ax2.bar(animal_types, counts, color=colors, alpha=0.8)
            ax2.set_title('Animal Detection Distribution', fontsize=14, fontweight='bold')
            ax2.set_xlabel('Animal Type')
            ax2.set_ylabel('Detection Count')
            plt.setp(ax2.xaxis.get_majorticklabels(), rotation=45, ha='right')
            
            # Add value labels on bars
            for bar, count in zip(bars, counts):
                height = bar.get_height()
                ax2.text(bar.get_x() + bar.get_width()/2., height,
                        f'{count}', ha='center', va='bottom')
        else:
            ax2.text(0.5, 0.5, 'No animal detections', 
                    ha='center', va='center', transform=ax2.transAxes, fontsize=12)
            ax2.set_title('Animal Detection Distribution', fontsize=14, fontweight='bold')
        
        # Plot 3: Confidence distribution
        if self.performance_metrics['classification_confidences']:
            ax3.hist(self.performance_metrics['classification_confidences'], 
                    bins=15, alpha=0.7, color='green', edgecolor='black')
            ax3.set_title('Classification Confidence Distribution', fontsize=14, fontweight='bold')
            ax3.set_xlabel('Confidence Score')
            ax3.set_ylabel('Frequency')
            ax3.grid(True, alpha=0.3)
        else:
            ax3.text(0.5, 0.5, 'No confidence data', 
                    ha='center', va='center', transform=ax3.transAxes, fontsize=12)
            ax3.set_title('Classification Confidence Distribution', fontsize=14, fontweight='bold')
        
        # Plot 4: Detection timeline
        if self.performance_metrics['detection_history']:
            ax4.plot(range(len(self.performance_metrics['detection_history'])), 
                    self.performance_metrics['detection_history'], 
                    color='red', linewidth=2, marker='s', markersize=3)
            ax4.set_title('Detections Per Frame Over Time', fontsize=14, fontweight='bold')
            ax4.set_xlabel('Frame Number')
            ax4.set_ylabel('Number of Detections')
            ax4.grid(True, alpha=0.3)
            ax4.set_ylim(0, max(self.performance_metrics['detection_history']) * 1.2)
        else:
            ax4.text(0.5, 0.5, 'No detection history data', 
                    ha='center', va='center', transform=ax4.transAxes, fontsize=12)
            ax4.set_title('Detections Per Frame Over Time', fontsize=14, fontweight='bold')
        
        plt.tight_layout()
        
        # Save the dashboard
        dashboard_path = os.path.join(self.config['output_dir'], 'performance_dashboard.png')
        plt.savefig(dashboard_path, dpi=150, bbox_inches='tight')
        print(f"Dashboard saved to: {dashboard_path}")
        plt.show()
    
    def save_detection_results(self):
        """Save detection results to file."""
        if self.config['save_detections']:
            # Generate report first
            report = self.generate_detection_report()
            
            # Save summary report
            report_file = os.path.join(self.config['output_dir'], 'detection_report.json')
            with open(report_file, 'w') as f:
                json.dump(report, f, indent=2)
            
            # Save detailed detections
            if self.detection_log:
                results_file = os.path.join(self.config['output_dir'], 'detailed_detections.json')
                with open(results_file, 'w') as f:
                    json.dump({
                        'metadata': report,
                        'detections': self.detection_log
                    }, f, indent=2)
            
            print(f"Results saved to: {self.config['output_dir']}")
    
    def run_live_farm_monitoring(self, video_source=0, max_frames=200):
        """Run the complete farm animal monitoring pipeline."""
        print("🚜 Starting Farm Animal Monitoring Pipeline...")
        print(f"📊 Monitoring for: {', '.join(self.farm_animal_classes)}")
        print("🎮 Controls: 'q'=Quit, 'r'=Report, 'd'=Dashboard, 't'=Toggle Demo Mode")
        
        # Setup components
        self.setup_yolo_detector()
        self.create_farm_animal_classifier()
        
        # Initialize video capture
        cap = cv2.VideoCapture(video_source)
        
        if not cap.isOpened():
            print("❌ Error: Could not open video source")
            return
        
        self.frame_count = 0
        print("✅ Pipeline started!")
        
        while self.frame_count < max_frames:
            ret, frame = cap.read()
            if not ret:
                print("📹 End of video stream")
                break
            
            # Process frame through pipeline
            processed_frame, detections = self.process_frame(frame)
            
            # Display frame with information
            cv2.putText(processed_frame, f"Frame: {self.frame_count}", (10, 30), 
                       cv2.FONT_HERSHEY_SIMPLEX, 0.7, (0, 255, 0), 2)
            cv2.putText(processed_frame, f"Detections: {len(detections)}", (10, 60), 
                       cv2.FONT_HERSHEY_SIMPLEX, 0.7, (0, 255, 0), 2)
            cv2.putText(processed_frame, f"Mode: {'DEMO' if self.demo_mode else 'REAL'}", (10, 90), 
                       cv2.FONT_HERSHEY_SIMPLEX, 0.7, (0, 255, 0), 2)
            cv2.putText(processed_frame, "Press 'q' to quit, 'd' for dashboard", (10, 120), 
                       cv2.FONT_HERSHEY_SIMPLEX, 0.5, (255, 255, 255), 1)
            
            cv2.imshow('Farm Animal Monitoring', processed_frame)
            
            # Handle key presses
            key = cv2.waitKey(1) & 0xFF
            if key == ord('q'):
                break
            elif key == ord('r'):
                report = self.generate_detection_report()
                print("\n" + "="*50)
                print("📊 CURRENT DETECTION REPORT")
                print("="*50)
                for key, value in report.items():
                    print(f"  {key}: {value}")
                print("="*50)
            elif key == ord('d'):
                self.visualize_performance_metrics()
            elif key == ord('t'):
                self.demo_mode = not self.demo_mode
                print(f"🔄 Mode switched to: {'DEMO' if self.demo_mode else 'REAL'}")
        
        # Cleanup and final reporting
        cap.release()
        cv2.destroyAllWindows()
        
        # Generate final reports
        print("\n" + "="*50)
        print("🎯 FINAL DETECTION REPORT")
        print("="*50)
        final_report = self.generate_detection_report()
        for key, value in final_report.items():
            print(f"  {key}: {value}")
        print("="*50)
        
        # Save results
        self.save_detection_results()
        
        # Show final dashboard
        self.visualize_performance_metrics()

# Run the pipeline
if __name__ == "__main__":
    # Paths to YOLO files
    YOLO_WEIGHTS_PATH = "yolov3.weights"
    YOLO_CONFIG_PATH = "yolov3.cfg"
    YOLO_CLASSES_PATH = "coco.names"
    
    try:
        # Create and run the pipeline
        pipeline = FarmAnimalPipeline(
            yolo_weights_path=YOLO_WEIGHTS_PATH,
            yolo_config_path=YOLO_CONFIG_PATH,
            yolo_classes_path=YOLO_CLASSES_PATH
        )
        
        # Run live monitoring
        pipeline.run_live_farm_monitoring(video_source=0, max_frames=100)
        
    except Exception as e:
        print(f"❌ Error: {e}")
        print("\n💡 Troubleshooting tips:")
        print("1. Check if YOLO files exist in the correct location")
        print("2. Ensure your webcam is connected and working")
        print("3. Try running with fewer frames: pipeline.run_live_farm_monitoring(max_frames=50)")
        print("4. The system will use demo mode if real detection fails")